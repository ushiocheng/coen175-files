#if !defined(GLOBAL_CONFIG_HPP)
#define GLOBAL_CONFIG_HPP

#define DEBUG
#ifndef DEBUG
#define NDEBUG  // to suppress assert
#endif

#endif  // GLOBAL_CONFIG_HPP