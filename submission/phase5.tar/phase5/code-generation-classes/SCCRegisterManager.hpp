#if !defined(SCC_REGISTER_MANAGER_HPP)
#define SCC_REGISTER_MANAGER_HPP

#include "SCCRegister.hpp"

// Since I am essentially making a class with all static member
namespace SCCRegisterManager {

}

#endif // SCC_REGISTER_MANAGER_HPP
