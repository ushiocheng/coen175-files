#include "SCCASTStatement.hpp"

SCCASTClasses::Statement::~Statement() {}