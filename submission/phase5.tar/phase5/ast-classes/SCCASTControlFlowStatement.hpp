#if !defined(SCC_AST_CONTROL_FLOW_STATEMENT_HPP)
#define SCC_AST_CONTROL_FLOW_STATEMENT_HPP

#include "SCCASTExpression.hpp"
#include "SCCASTStatement.hpp"

namespace SCCASTClasses {

class CtrFlowStmt : public Statement {
};

}  // namespace SCCASTClasses

#endif  // SCC_AST_CONTROL_FLOW_STATEMENT_HPP
