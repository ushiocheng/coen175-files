#if !defined(SCC_AST_STATEMENT)
#define SCC_AST_STATEMENT
#include "../semantic-classes/SCCScope.hpp"

namespace SCCASTClasses {

/**
 * Virtual class, enclosing CFS and Expr
 */
class Statement {
   public:
    virtual ~Statement();

    enum StmtType { ASSIGN = 0, EXPR, RETURN, WHILE, FOR, IF, BLOCK };
    /**
     * idenitfy API for RTTI
     */
    virtual StmtType identify() const = 0;

    /**
     * Phase 4 - Perform Static Type Checking
     * @return true if no error is generated on type checking
     */
    virtual bool performTypeChecking() const = 0;

    /**
     * Phase 5 - Generate Code
     * @param out output stream
     */
    virtual void generateCode(std::ostream& out,
                              const char* indentation = "") const = 0;
};

}  // namespace SCCASTClasses

#endif  // SCC_AST_STATEMENT
